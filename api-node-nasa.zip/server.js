const express = require('express');
const app = express();
const cors = require('cors');
const rotas = require('./routes/routes');

var corsOptions = {
    origin: "*",
    optionsSuccessStatus: 200
};

app.use(cors(corsOptions))
app.use(express.json())
app.use(rotas)
app.listen('8000');

