const express = require('express');
const routers = express.Router();
const SessionController = require('../database/database');

routers.post('/application/authenticate', SessionController.retornaUsuario);
routers.post('/application/buscaProjetos/idJurado', SessionController.retornaProjetosbyID);
routers.post('/application/lancaNotas/avaliado', SessionController.cadastraNotaTrabalho);
routers.post('/application/desclassifica/projeto', SessionController.desclassificaProjeto);
routers.get('/application/calculaClassificacao/Geral', SessionController.rankingProjetos);

module.exports = routers;