const { Client } = require('pg');
const cliente = new Client({
    user: 'postgres',
    host: 'database-1.c6jbapkztujp.us-east-1.rds.amazonaws.com',
    database: 'mainDatabase',
    password: 'chaliceWell906309',
    port: 5432
});
cliente.connect();

module.exports = cliente;