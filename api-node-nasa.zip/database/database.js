const client = require('./connection');

module.exports = {

    async retornaUsuario(req, res){
        const { username, password } = req.body;
        
        const query = client.query("SELECT id, username, nome, permission FROM users WHERE username = '" + String(username) + "' and password = '" + String(password) + "'").then(res => {
            console.log(res['rows'][0]);
            if(res['rows'][0] == undefined){
                console.log("Erro")

                let resp = {
                    Status: "Error"
                }
                return resp
            }else{
                
                return res['rows'][0]
            }
        })

        const response = await query;

        return res.json(response);
    },

    async retornaProjetosbyID(req, res){
        const { idjurado } = req.body;

        console.log(idjurado);

        const query = client.query("SELECT projetos_jurados.projeto, projetos_jurados.jurado, projetos_jurados.avaliado, projetos.name, projetos.link FROM projetos_jurados INNER JOIN projetos ON projetos_jurados.projeto = projetos.id WHERE projetos_jurados.jurado = '" + String(idjurado) +"'").then(res => {
            console.log(res['rows']);
            return res['rows']
        })

        const response = await query;

        return res.json(response);

    },

    async cadastraNotaTrabalho(req, res){
        const { projeto, jurado, notaInova, commentInova, notaAplica, commentAplica, notaVia, commentVia, notaInclui, commentInclui, notaSusten, commentSusten } = req.body;

        const query = client.query("INSERT INTO notas (id_projeto, id_jurado, nota_inovacao, comment_inovacao, nota_aplicabilidade, comment_aplica, nota_viabilidade, comment_viabilidade, nota_inclusao, comment_inclusao, nota_sustentabilidade, comment_susten, nasa_data) VALUES ('" + String(projeto) + "', '" + String(jurado) + "','" + String(notaInova) + "','" + String(commentInova) + "','" + String(notaAplica) + "','" + String(commentAplica) + "','" + String(notaVia) + "','" + String(commentVia) + "','" + String(notaInclui) + "','" + String(commentInclui) + "','" + String(notaSusten) + "','" + String(commentSusten) + "', true)").then(res => {
            console.log(res['rows']);
            return res['rows']
        });

        client.query("UPDATE projetos_jurados SET avaliado = 1 WHERE projeto = '" + String(projeto) + "' AND jurado = '" + String(jurado) + "'");

        const response = await query;

        console.log(response);

        return res.json(response);
    },

    async desclassificaProjeto(req, res){
        const { idProjeto } = req.body;

        client.query("UPDATE projetos_jurados SET avaliado = 2 WHERE projeto = '" + String(idProjeto) + "'");

        return res.json("OK")
    },

    async rankingProjetos(req, res){
        const {  } = req.body;

        console.log("cheguei aqui")

        const projetos = [];
        let inova = 0;
        let aplica = 0;
        let via = 0;
        let inclui = 0;
        let sustem = 0;
        

        const buscaProjetos = client.query("SELECT avaliado, projetos.id, projetos.name FROM projetos_jurados INNER JOIN projetos ON projetos.id = projetos_jurados.projeto AND projetos_jurados.avaliado = 1").then(res => {
            return res['rows'];
        });

        const response = await buscaProjetos;

        for(const element of response){
            
            const notas = client.query("SELECT notas.nota_inovacao, notas.nota_aplicabilidade, notas.nota_viabilidade, notas.nota_inclusao, notas.nota_sustentabilidade FROM notas WHERE id_projeto = '" + String(element['id']) + "'").then(res => {
                const arrayNotas = res['rows'];

                console.log(arrayNotas);

                arrayNotas.forEach(element => {
                    inova += parseFloat(element['nota_inovacao']);
                    aplica += parseFloat(element['nota_aplicabilidade']);
                    via += parseFloat(element['nota_viabilidade']);
                    inclui += parseFloat(element['nota_inclusao']);
                    sustem += parseFloat(element['nota_sustentabilidade']);
                });

                console.log(arrayNotas);

                return arrayNotas;
            });

            let tamanho = (await notas).length;

            console.log(notas);

            const objectArray = {"id": element['id'], "name": element['name'], "nota_inclusao": (inclui / tamanho), "nota_aplicabilidade" : (aplica / tamanho), "nota_viabilidade": (via / tamanho), "nota_inovacao": (inova / tamanho), "nota_sustentabilidade" : (sustem / tamanho), "classificacao": (((inova / tamanho) + (via / tamanho) + (sustem / tamanho) + (aplica / tamanho) + (inclui / tamanho)) / 5)};

            projetos.push(objectArray);

        }

        return res.json(projetos);
    },
};